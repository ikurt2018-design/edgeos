/* =========================
   THEME SYSTEM
========================= */
function applyThemeVars(theme){
  if(theme === "light"){
    document.documentElement.style.setProperty("--bg", "#e9eefc");
    document.documentElement.style.setProperty("--panel", "rgba(255,255,255,.92)");
    document.documentElement.style.setProperty("--panel2", "rgba(0,0,0,.06)");
    document.documentElement.style.setProperty("--text", "#0b1020");
  } else if(theme === "neon"){
    document.documentElement.style.setProperty("--bg", "#05010a");
    document.documentElement.style.setProperty("--panel", "rgba(20,10,35,.92)");
    document.documentElement.style.setProperty("--panel2", "rgba(255,255,255,.09)");
    document.documentElement.style.setProperty("--text", "#ffffff");
  } else { // dark
    document.documentElement.style.setProperty("--bg", "#0b1020");
    document.documentElement.style.setProperty("--panel", "rgba(25,30,50,.95)");
    document.documentElement.style.setProperty("--panel2", "rgba(255,255,255,.08)");
    document.documentElement.style.setProperty("--text", "#ffffff");
  }
}
function setTheme(t){
  localStorage.setItem("edgeos_theme", t);
  applyThemeVars(t);
}
function setAccent(hex){
  localStorage.setItem("edgeos_accent", hex);
  document.documentElement.style.setProperty("--accent", hex);
}
// init
applyThemeVars(localStorage.getItem("edgeos_theme") || "dark");
document.documentElement.style.setProperty("--accent", localStorage.getItem("edgeos_accent") || "#2563eb");

// sync UI if present
setTimeout(() => {
  const sel = document.getElementById("themeSelect");
  const acc = document.getElementById("accentPick");
  if(sel) sel.value = localStorage.getItem("edgeos_theme") || "dark";
  if(acc) acc.value = localStorage.getItem("edgeos_accent") || "#2563eb";
}, 0);

/* =========================
   POWERWASH
========================= */
function powerwash(){
  const ok = confirm("Powerwash will erase EdgeOS (apps, files, settings). Continue?");
  if(!ok) return;

  // Remove only EdgeOS keys (keep other sites data untouched)
  const keys = Object.keys(localStorage);
  for(const k of keys){
    if(k.startsWith("edgeos_")) localStorage.removeItem(k);
  }
  alert("Powerwash complete. Rebooting to installer…");
  location.reload();
}

/* =========================
   FILE MANAGER (localStorage DB)
   Stores files as {id,name,type,data(base64),mtime}
========================= */
let selectedFileId = null;

function loadFilesDB(){
  try { return JSON.parse(localStorage.getItem("edgeos_files_db") || "[]"); }
  catch { return []; }
}
function saveFilesDB(arr){
  localStorage.setItem("edgeos_files_db", JSON.stringify(arr));
}
function fileId(){
  return "f_" + Math.random().toString(36).slice(2) + Date.now();
}
function renderFiles(){
  const list = document.getElementById("filesList");
  if(!list) return;
  const q = (document.getElementById("filesSearch")?.value || "").toLowerCase();

  const db = loadFilesDB()
    .filter(f => !q || f.name.toLowerCase().includes(q))
    .sort((a,b) => b.mtime - a.mtime);

  list.innerHTML = "";
  for(const f of db){
    const row = document.createElement("div");
    row.className = "file-item" + (f.id === selectedFileId ? " active" : "");
    row.onclick = () => selectFile(f.id);

    const left = document.createElement("span");
    left.textContent = f.name;

    const right = document.createElement("span");
    right.style.opacity = ".7";
    right.textContent = (f.type || "").split("/")[1] || "file";

    row.appendChild(left);
    row.appendChild(right);
    list.appendChild(row);
  }
}
function selectFile(id){
  selectedFileId = id;
  const db = loadFilesDB();
  const f = db.find(x => x.id === id);
  document.getElementById("previewName").textContent = f ? f.name : "No file selected";

  const ta = document.getElementById("previewText");
  if(!f){ ta.value = ""; ta.disabled = true; renderFiles(); return; }

  // editable only for text/*
  const isText = (f.type || "").startsWith("text/") || f.name.endsWith(".txt");
  ta.disabled = !isText;
  ta.value = isText ? atob(f.data || "") : "[Binary file - download to view]";
  renderFiles();
}
function savePreviewEdits(){
  const ta = document.getElementById("previewText");
  if(!selectedFileId || ta.disabled) return;
  const db = loadFilesDB();
  const f = db.find(x => x.id === selectedFileId);
  if(!f) return;
  f.data = btoa(ta.value);
  f.mtime = Date.now();
  saveFilesDB(db);
  renderFiles();
}
async function importFiles(){
  const input = document.getElementById("fileImport");
  const files = Array.from(input.files || []);
  if(files.length === 0) return;

  const db = loadFilesDB();

  for(const file of files){
    const buf = await file.arrayBuffer();
    const bytes = new Uint8Array(buf);
    // base64 encode
    let bin = "";
    const chunk = 0x8000;
    for(let i=0;i<bytes.length;i+=chunk){
      bin += String.fromCharCode(...bytes.slice(i,i+chunk));
    }
    const b64 = btoa(bin);

    db.push({
      id: fileId(),
      name: file.name,
      type: file.type || "application/octet-stream",
      data: b64,
      mtime: Date.now()
    });
  }

  saveFilesDB(db);
  input.value = "";
  renderFiles();
}
function downloadSelected(){
  if(!selectedFileId) return;
  const db = loadFilesDB();
  const f = db.find(x => x.id === selectedFileId);
  if(!f) return;

  const bin = atob(f.data || "");
  const bytes = new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++) bytes[i] = bin.charCodeAt(i);

  const blob = new Blob([bytes], {type: f.type || "application/octet-stream"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = f.name;
  document.body.appendChild(a);
  a.click();
  a.remove();
}
function deleteSelected(){
  if(!selectedFileId) return;
  const ok = confirm("Delete selected file?");
  if(!ok) return;
  const db = loadFilesDB().filter(x => x.id !== selectedFileId);
  saveFilesDB(db);
  selectedFileId = null;
  selectFile(null);
  renderFiles();
}
function renameSelected(){
  if(!selectedFileId) return;
  const db = loadFilesDB();
  const f = db.find(x => x.id === selectedFileId);
  if(!f) return;
  const n = prompt("New name:", f.name);
  if(!n) return;
  f.name = n.trim();
  f.mtime = Date.now();
  saveFilesDB(db);
  selectFile(selectedFileId);
  renderFiles();
}
function newTextFile(){
  const name = prompt("File name (e.g. notes.txt):", "newfile.txt");
  if(!name) return;
  const db = loadFilesDB();
  db.push({
    id: fileId(),
    name: name.trim(),
    type: "text/plain",
    data: btoa(""),
    mtime: Date.now()
  });
  saveFilesDB(db);
  renderFiles();
}
// initial render if window exists
setTimeout(renderFiles, 0);

/* =========================
   EDGEWORD SETTINGS + EXPORT
========================= */
let autosaveWord = true;

function loadWordSettings(){
  const s = JSON.parse(localStorage.getItem("edgeos_word_settings") || "{}");
  return {
    font: s.font || "system-ui",
    size: s.size || 16,
    line: s.line || 1.6,
    pageW: s.pageW || 820,
    autosave: s.autosave ?? "on"
  };
}
function applyWordSettings(){
  const wsFont = document.getElementById("wsFont");
  const wsSize = document.getElementById("wsSize");
  const wsLine = document.getElementById("wsLine");
  const wsPageW = document.getElementById("wsPageW");
  const wsAutosave = document.getElementById("wsAutosave");
  const ed = document.getElementById("wordEditor");
  if(!ed) return;

  const cfg = {
    font: wsFont?.value || "system-ui",
    size: parseInt(wsSize?.value || "16", 10),
    line: parseFloat(wsLine?.value || "1.6"),
    pageW: parseInt(wsPageW?.value || "820", 10),
    autosave: wsAutosave?.value || "on"
  };

  ed.style.fontFamily = cfg.font;
  ed.style.fontSize = cfg.size + "px";
  ed.style.lineHeight = String(cfg.line);
  ed.style.width = cfg.pageW + "px";

  autosaveWord = (cfg.autosave === "on");
  localStorage.setItem("edgeos_word_settings", JSON.stringify(cfg));
}
function exportWordAsHTML(){
  const title = document.getElementById("wordTitle")?.value || "document";
  const html = document.getElementById("wordEditor")?.innerHTML || "";
  const payload = `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(title)}</title></head><body>${html}</body></html>`;
  const blob = new Blob([payload], {type:"text/html"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = (title.replace(/[^\w\- ]+/g,"").trim() || "document") + ".html";
  document.body.appendChild(a);
  a.click();
  a.remove();
}
function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

// EdgeWord load/save
setTimeout(() => {
  const ed = document.getElementById("wordEditor");
  const tt = document.getElementById("wordTitle");
  if(!ed || !tt) return;

  ed.innerHTML = localStorage.getItem("edgeos_word_content") || "";
  tt.value = localStorage.getItem("edgeos_word_title") || "Untitled";

  const cfg = loadWordSettings();
  // set UI values if settings window exists
  const wsFont = document.getElementById("wsFont");
  const wsSize = document.getElementById("wsSize");
  const wsLine = document.getElementById("wsLine");
  const wsPageW = document.getElementById("wsPageW");
  const wsAutosave = document.getElementById("wsAutosave");
  if(wsFont) wsFont.value = cfg.font;
  if(wsSize) wsSize.value = cfg.size;
  if(wsLine) wsLine.value = cfg.line;
  if(wsPageW) wsPageW.value = cfg.pageW;
  if(wsAutosave) wsAutosave.value = cfg.autosave;

  applyWordSettings();

  const save = () => {
    if(!autosaveWord) return;
    localStorage.setItem("edgeos_word_content", ed.innerHTML);
    localStorage.setItem("edgeos_word_title", tt.value);
  };
  ed.addEventListener("input", save);
  tt.addEventListener("input", save);
}, 0);

/* =========================
   GAMES: SNAKE + TICTACTOE
========================= */
const canvas = document.getElementById("gameCanvas");
const ctx = canvas?.getContext("2d");
let gameLoop = null;

function clearGame(){
  if(gameLoop) { clearInterval(gameLoop); gameLoop = null; }
  if(ctx){ ctx.clearRect(0,0,canvas.width,canvas.height); }
  window.onkeydown = null;
}

function openSnake(){
  openWin("gamesWin");
  clearGame();
  if(!ctx) return;

  const grid = 20;
  let snake = [{x:10,y:10}];
  let dir = {x:1,y:0};
  let food = {x:15,y:12};
  let score = 0;

  function randFood(){
    food = {x: Math.floor(Math.random()* (canvas.width/grid)),
            y: Math.floor(Math.random()* (canvas.height/grid))};
  }
  function draw(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    // food
    ctx.fillRect(food.x*grid, food.y*grid, grid, grid);
    // snake
    for(const s of snake){
      ctx.fillRect(s.x*grid, s.y*grid, grid, grid);
    }
    ctx.fillText("Score: " + score, 10, 16);
  }
  function step(){
    const head = {x: snake[0].x + dir.x, y: snake[0].y + dir.y};
    const maxX = canvas.width/grid, maxY = canvas.height/grid;
    if(head.x<0||head.y<0||head.x>=maxX||head.y>=maxY) return gameOver();
    if(snake.some(p=>p.x===head.x&&p.y===head.y)) return gameOver();
    snake.unshift(head);

    if(head.x===food.x && head.y===food.y){
      score++;
      randFood();
    } else {
      snake.pop();
    }
    draw();
  }
  function gameOver(){
    clearGame();
    alert("Snake game over. Score: " + score);
  }

  window.onkeydown = (e) => {
    if(e.key==="ArrowUp" && dir.y!==1) dir={x:0,y:-1};
    if(e.key==="ArrowDown" && dir.y!==-1) dir={x:0,y:1};
    if(e.key==="ArrowLeft" && dir.x!==1) dir={x:-1,y:0};
    if(e.key==="ArrowRight" && dir.x!==-1) dir={x:1,y:0};
  };

  randFood();
  draw();
  gameLoop = setInterval(step, 120);
}

function openTicTacToe(){
  openWin("gamesWin");
  clearGame();
  if(!ctx) return;

  const size = 140;
  let board = Array(9).fill("");
  let player = "X";

  function draw(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    // grid
    for(let i=1;i<=2;i++){
      ctx.fillRect(i*size, 20, 3, size*3);
      ctx.fillRect(0, 20+i*size, size*3, 3);
    }
    ctx.font = "64px system-ui";
    for(let i=0;i<9;i++){
      const x = (i%3)*size + 45;
      const y = Math.floor(i/3)*size + 95;
      ctx.fillText(board[i], x, y);
    }
    ctx.font = "16px system-ui";
    ctx.fillText("Click to play. Turn: " + player, 10, 16);
  }
  function win(){
    const w = [
      [0,1,2],[3,4,5],[6,7,8],
      [0,3,6],[1,4,7],[2,5,8],
      [0,4,8],[2,4,6],
    ];
    for(const [a,b,c] of w){
      if(board[a] && board[a]===board[b] && board[a]===board[c]) return board[a];
    }
    if(board.every(Boolean)) return "D";
    return null;
  }

  canvas.onclick = (ev) => {
    const rect = canvas.getBoundingClientRect();
    const cx = (ev.clientX - rect.left) * (canvas.width/rect.width);
    const cy = (ev.clientY - rect.top) * (canvas.height/rect.height);

    // ignore top bar area
    if(cy < 20) return;
    const col = Math.floor(cx / size);
    const row = Math.floor((cy-20) / size);
    if(col<0||col>2||row<0||row>2) return;
    const idx = row*3 + col;
    if(board[idx]) return;

    board[idx] = player;
    const r = win();
    if(r){
      draw();
      alert(r==="D" ? "Draw!" : r + " wins!");
      board = Array(9).fill("");
      player = "X";
      draw();
      return;
    }
    player = (player==="X" ? "O" : "X");
    draw();
  };

  draw();
}
