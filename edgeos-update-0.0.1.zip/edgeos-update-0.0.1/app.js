let z = 10;
const winState = {};

/* Window controls */
function openWin(id) {
  const w = document.getElementById(id);
  w.style.display = "block";
  w.style.zIndex = ++z;
  if (!w.style.top) {
    w.style.top = "120px";
    w.style.left = "120px";
  }
}

function closeWin(id) {
  document.getElementById(id).style.display = "none";
}

function minWin(id) {
  document.getElementById(id).style.display = "none";
}

function maxWin(id) {
  const w = document.getElementById(id);
  if (!winState[id]) {
    winState[id] = {
      top: w.style.top,
      left: w.style.left,
      width: w.style.width,
      height: w.style.height
    };
  }
  w.classList.toggle("maximized");
  if (!w.classList.contains("maximized")) {
    Object.assign(w.style, winState[id]);
  }
}

/* Dragging */
let drag = null, dx = 0, dy = 0;
document.addEventListener("mousedown", e => {
  const bar = e.target.closest(".titlebar");
  if (!bar) return;
  drag = document.getElementById(bar.dataset.drag);
  dx = e.clientX - drag.offsetLeft;
  dy = e.clientY - drag.offsetTop;
  drag.style.zIndex = ++z;
});
document.addEventListener("mousemove", e => {
  if (!drag || drag.classList.contains("maximized")) return;
  drag.style.left = e.clientX - dx + "px";
  drag.style.top = e.clientY - dy + "px";
});
document.addEventListener("mouseup", () => drag = null);

/* Browser */
const iframe = document.getElementById("browserView");
const urlBar = document.getElementById("urlBar");
let history = [], index = -1;

function navigate() {
  let q = urlBar.value.trim();
  let url;

  if (q.includes("google.com")) {
    window.open("https://www.google.com", "_blank");
    return;
  }

  if (!q.includes(".") && !q.startsWith("http")) {
    url = "https://duckduckgo.com/?q=" + encodeURIComponent(q);
  } else {
    if (!q.startsWith("http")) q = "https://" + q;
    url = q;
  }

  iframe.src = url;
  history = history.slice(0, ++index);
  history.push(url);
}

function goBack() {
  if (index > 0) iframe.src = history[--index];
}

function goForward() {
  if (index < history.length - 1) iframe.src = history[++index];
}

function refreshPage() {
  iframe.src = iframe.src;
}

/* Notepad save */
const note = document.getElementById("noteArea");
note.value = localStorage.getItem("edgeos_notepad") || "";
note.addEventListener("input", () => {
  localStorage.setItem("edgeos_notepad", note.value);
});

/* Update system */
async function installEdgeOS() {
  const file = document.getElementById("edgeUpdate").files[0];
  const status = document.getElementById("edgeStatus");
  if (!file) return;

  status.textContent = "Installing update…";
  const zip = await JSZip.loadAsync(file);

  localStorage.setItem(
    "edgeos_app_html",
    await zip.file("app.html").async("string")
  );
  localStorage.setItem(
    "edgeos_app_js",
    await zip.file("app.js").async("string")
  );
  localStorage.setItem(
    "edgeos_app_css",
    await zip.file("style.css").async("string")
  );

  localStorage.setItem("edgeos_version", "0.0.1");
  location.reload();
}

/* Start */
openWin("browserWin");
